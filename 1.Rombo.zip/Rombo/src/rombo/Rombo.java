/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rombo;

import java.util.Scanner;

public class Rombo {

    static void mostrarM(int m[][], int n) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                System.out.print("\t" + m[i][j]);
            }
            System.out.print("\n");

        }
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int m[][] = new int[50][50];
        System.out.print("tamaño de la matriz:");
        int n = in.nextInt();
        int i = 1, j = 1, pi = (n / 2) + 1, s = 1, t = 1, c = 0, p = pi, k = 0;
        while (k != n * n-(n/2)) {
            if (j == p) {
                m[i][j] = s;
                s++;
                c++;
                if (c == t) {
                    if (i < (n / 2) + 1) {
                        pi = pi - 1;
                        p = pi;
                        t = t + 2;
                        c = 0;
                    } else {
                        pi = pi + 1;
                        p = pi;
                        t = t - 2;
                        c = 0;
                    }

                } else {
                    p++;
                }

            } else {
                m[i][j] = 0;

            }
            j++;
            if (j > n) {
                i++;
                j = 1;
            }
            k++;
        }
        mostrarM(m,n);
    }

}
