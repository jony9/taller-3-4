
import java.util.Arrays;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrador
 */
public class menu {
    
    private int[][] matriz; 
    private int dimension; 
    private int valores; 
 
    public menu(int n) { 
        matriz = new int[n][n]; 
        dimension = n; 
        valores = n * n; 
        rellenar(); 
    } 
 
    private void rellenar() { 
        int fila, vuelta = 0, col, val = 1; 
        while (val <= valores) { 
 
            for (col = vuelta, fila = vuelta; val <= valores && col < dimension - 1 - vuelta; col++) { 
                matriz[fila][col] = val; 
                val++; 
            } 
 
            for (col = dimension - 1 - vuelta, fila = vuelta; val <= valores && fila < dimension - 1 - vuelta; fila++) { 
                matriz[fila][col] = val; 
                val++; 
            } 
 
            for (col = dimension - 1 - vuelta, fila = dimension - 1 - vuelta; val <= valores && col > vuelta; col--) { 
                matriz[fila][col] = val; 
                val++; 
            } 
 
            for (col = vuelta, fila = dimension - 1 - vuelta; val <= valores && fila > vuelta; fila--) { 
                matriz[fila][col] = val; 
                val++; 
            } 
 
            if (dimension % 2 != 0 && val == valores) { 
                col = fila = dimension / 2; 
                matriz[fila][col] = val; 
                val++; 
            } 
            vuelta++; 
        } 
    } 
 
    @Override 
    public String toString() { 
        String out = ""; 
         
          for (int i = 0; i < dimension; i++) { 
          out+=(Arrays.toString(matriz[i])); 
          out+="\n"; 
        } 
        return out; 
    } 
} 

