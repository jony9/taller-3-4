public class Matriz { 
    public static void main(String[] args){ 
        System.out.println(new menu(4)); 
    } 
} 